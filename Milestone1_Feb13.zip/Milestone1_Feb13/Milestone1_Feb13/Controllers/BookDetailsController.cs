﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Milestone1_Feb13.Models;

namespace Milestone1_Feb13.Controllers
{
    public class BookDetailsController : Controller
    {
        private readonly LibraryContext _context;

        public BookDetailsController(LibraryContext context)
        {
            _context = context;
        }

        // GET: BookDetails
        public async Task<IActionResult> Index()
        {
              return View(await _context.BookDetails.ToListAsync());
        }

        // GET: BookDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.BookDetails == null)
            {
                return NotFound();
            }

            var bookDetail = await _context.BookDetails
                .FirstOrDefaultAsync(m => m.BookId == id);
            if (bookDetail == null)
            {
                return NotFound();
            }

            return View(bookDetail);
        }

        // GET: BookDetails/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BookDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookId,BookName,AuthorId,AuthorName,YearOfPublish")] BookDetail bookDetail)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bookDetail);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(bookDetail);
        }

        // GET: BookDetails/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.BookDetails == null)
            {
                return NotFound();
            }

            var bookDetail = await _context.BookDetails.FindAsync(id);
            if (bookDetail == null)
            {
                return NotFound();
            }
            return View(bookDetail);
        }

        // POST: BookDetails/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookId,BookName,AuthorId,AuthorName,YearOfPublish")] BookDetail bookDetail)
        {
            if (id != bookDetail.BookId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bookDetail);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookDetailExists(bookDetail.BookId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(bookDetail);
        }

        // GET: BookDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.BookDetails == null)
            {
                return NotFound();
            }

            var bookDetail = await _context.BookDetails
                .FirstOrDefaultAsync(m => m.BookId == id);
            if (bookDetail == null)
            {
                return NotFound();
            }

            return View(bookDetail);
        }

        // POST: BookDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.BookDetails == null)
            {
                return Problem("Entity set 'LibraryContext.BookDetails'  is null.");
            }
            var bookDetail = await _context.BookDetails.FindAsync(id);
            if (bookDetail != null)
            {
                _context.BookDetails.Remove(bookDetail);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookDetailExists(int id)
        {
          return _context.BookDetails.Any(e => e.BookId == id);
        }
    }
}
