﻿using System;
using System.Collections.Generic;

namespace Milestone1_Feb13.Models
{
    public partial class BookDetail
    {
        public int BookId { get; set; }
        public string? BookName { get; set; }
        public int AuthorId { get; set; }
        public string? AuthorName { get; set; }
        public DateTime? YearOfPublish { get; set; }
    }
}
