﻿using System;
using System.Collections.Generic;

namespace Milestone1_Feb13.Models
{
    public partial class BorrowDetail
    {
        public int BorrowedId { get; set; }
        public int StudentId { get; set; }
        public string? StudentName { get; set; }
        public int BookId { get; set; }
        public string? BookName { get; set; }
        public DateTime? TakenDate { get; set; }
        public DateTime? ReturnDate { get; set; }
    }
}
