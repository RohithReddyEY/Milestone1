﻿using System;
using System.Collections.Generic;

namespace Milestone1_Feb13.Models
{
    public partial class StudentDetail
    {
        public int StudentId { get; set; }
        public string? StudentName { get; set; }
        public int? StudentAge { get; set; }
        public string? StudentGender { get; set; }
        public string? StudentDepartment { get; set; }
    }
}
