﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Milestone1_Feb13.Models
{
    public partial class LibraryContext : DbContext
    {
        public LibraryContext()
        {
        }

        public LibraryContext(DbContextOptions<LibraryContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AuthorDetail> AuthorDetails { get; set; } = null!;
        public virtual DbSet<BookDetail> BookDetails { get; set; } = null!;
        public virtual DbSet<BorrowDetail> BorrowDetails { get; set; } = null!;
        public virtual DbSet<StudentDetail> StudentDetails { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//                optionsBuilder.UseSqlServer("Data Source=IN3242887W2\\SQLEXPRESS;Initial Catalog=Library;Trusted_Connection=True;TrustServerCertificate=True;database=Library");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AuthorDetail>(entity =>
            {
                entity.HasKey(e => e.AuthorId);

                entity.ToTable("Author_Details");

                entity.Property(e => e.AuthorId).HasColumnName("Author Id");

                entity.Property(e => e.AuthorName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Author Name");

                entity.Property(e => e.BookId).HasColumnName("Book Id");

                entity.Property(e => e.BookName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Book Name");

                entity.Property(e => e.YearOfPublish)
                    .HasColumnType("date")
                    .HasColumnName("Year of Publish");
            });

            modelBuilder.Entity<BookDetail>(entity =>
            {
                entity.HasKey(e => e.BookId);

                entity.ToTable("Book_Details");

                entity.Property(e => e.BookId).HasColumnName("Book Id");

                entity.Property(e => e.AuthorId).HasColumnName("Author Id");

                entity.Property(e => e.AuthorName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Author Name");

                entity.Property(e => e.BookName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Book Name");

                entity.Property(e => e.YearOfPublish)
                    .HasColumnType("date")
                    .HasColumnName("Year of Publish");
            });

            modelBuilder.Entity<BorrowDetail>(entity =>
            {
                entity.HasKey(e => e.BorrowedId);

                entity.ToTable("Borrow_Details");

                entity.Property(e => e.BorrowedId).HasColumnName("Borrowed Id");

                entity.Property(e => e.BookId).HasColumnName("Book Id");

                entity.Property(e => e.BookName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Book Name");

                entity.Property(e => e.ReturnDate)
                    .HasColumnType("date")
                    .HasColumnName("Return Date");

                entity.Property(e => e.StudentId).HasColumnName("Student Id");

                entity.Property(e => e.StudentName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Student Name");

                entity.Property(e => e.TakenDate)
                    .HasColumnType("date")
                    .HasColumnName("Taken Date");
            });

            modelBuilder.Entity<StudentDetail>(entity =>
            {
                entity.HasKey(e => e.StudentId);

                entity.ToTable("Student_Details");

                entity.Property(e => e.StudentId).HasColumnName("Student Id");

                entity.Property(e => e.StudentAge).HasColumnName("Student Age");

                entity.Property(e => e.StudentDepartment)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Student Department");

                entity.Property(e => e.StudentGender)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Student Gender");

                entity.Property(e => e.StudentName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Student Name");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
